
package com.rpg.test;

import com.rpg.test.CharacterDuel;
import com.rpg.test.TestCharacter;

public class RPG {

    public static void main(String[] args) {
       TestCharacter tc = new TestCharacter();
       
       CharacterDuel cd = new CharacterDuel();
       
    }
    
}
