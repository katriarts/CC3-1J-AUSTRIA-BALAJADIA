
package com.rpg.item;

public interface Weapons {
    public int useWeapon();
    
}
