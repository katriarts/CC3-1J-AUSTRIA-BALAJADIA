package com.rpg.item;




public interface Armor {
    public int useArmor();
        
    
}
